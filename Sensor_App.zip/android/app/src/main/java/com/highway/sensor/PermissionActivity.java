package com.highway.sensor;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.highway.sensor.ui.MainActivity;

public class PermissionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        check_and_request();
    }

    private static final String[] PERMISSIONS_REQUIRED = {Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};

    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Toast.makeText(PermissionActivity.this, "Permission request granted", Toast.LENGTH_LONG).show();
                    navigateToCamera();
                } else {
                    Toast.makeText(PermissionActivity.this, "Permission request denied", Toast.LENGTH_LONG).show();
                }
            });


    private void check_and_request(){
        if (PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
        )) {
            if (PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            )) {
                if (PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                )) {
                    navigateToCamera();
                }
                else {
                    requestPermissionLauncher.launch(
                            Manifest.permission.ACCESS_FINE_LOCATION);
                }

            }
            else {
                requestPermissionLauncher.launch(
                        Manifest.permission.ACCESS_COARSE_LOCATION);
            }

        }
        else {
            requestPermissionLauncher.launch(
                    Manifest.permission.CAMERA);
        }
    }

    boolean started = false;
    boolean called = false;

    @Override
    public void onResume() {
        started = true;
        if (called) navigateToCamera();
        super.onResume();
    }
    private void navigateToCamera() {

        if (started)
            startActivity(new Intent(this, MainActivity.class));
        else called = true;
    }
    public static boolean hasPermissions(Context context){

        for (String s : PERMISSIONS_REQUIRED) {
            if (ContextCompat.checkSelfPermission(context, s) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }

        return true;
    }
}