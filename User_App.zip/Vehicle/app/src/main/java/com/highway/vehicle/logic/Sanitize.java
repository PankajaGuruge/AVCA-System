package com.highway.vehicle.logic;

public class Sanitize {


    public static String phone(String phone){
        if (phone.length() < 9 || phone.length() > 12) return null;
        if (phone.length() == 9) return "+94" + phone;
        if (phone.length() == 10) return "+94" + phone.substring(1);
        if (phone.length() == 11) return "94" + phone;

        return null;
    }

}
