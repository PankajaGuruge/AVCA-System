

package com.highway.sensor.ui;

import static androidx.camera.core.ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.common.util.concurrent.ListenableFuture;
import com.highway.sensor.DetectorHelper;
import com.highway.sensor.OverlayView;
import com.highway.sensor.PermissionActivity;
import com.highway.sensor.R;
import com.highway.sensor.logic.Function;

import org.tensorflow.lite.support.label.Category;
import org.tensorflow.lite.task.vision.detector.Detection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity
        implements DetectorHelper.DetectorListener {

    private static final String TAG = "ObjectDetection";

    private DetectorHelper detectorHelper;
    private Bitmap bitmapBuffer;
    private Preview preview;
    private ImageAnalysis imageAnalyzer;
    private Camera camera;
    private ProcessCameraProvider cameraProvider;

    private ExecutorService cameraExecutor;
    private Location location;

    // Initialize CameraX, and prepare to bind the camera use cases
    private void setUpCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider
                .getInstance(this);

        cameraProviderFuture.addListener(
                new Runnable() {
                    @Override
                    public void run() {
                        // CameraProvider
                        try {
                            cameraProvider = cameraProviderFuture.get();
                        } catch (ExecutionException | InterruptedException e) {
                            e.printStackTrace();
                        }
                        // Build and bind the camera use cases
                        bindCameraUseCases();
                    }
                },
                ContextCompat.getMainExecutor(MainActivity.this)
        );
    }

    // Declare and bind preview, capture and analysis use cases
    @SuppressLint("UnsafeOptInUsageError")
    private void bindCameraUseCases() {

        // CameraProvider
        if (cameraProvider == null) {
            throw new IllegalStateException("Camera initialization failed.");
        }
        // CameraSelector - makes assumption that we're only using the back camera
        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK).build();

        // Preview. Only using the 4:3 ratio because this is the closest to our models
        PreviewView view_finder = findViewById(R.id.view_finder);
        preview = new Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setTargetRotation(view_finder.getDisplay().getRotation())
                .build();

        // ImageAnalysis. Using RGBA 8888 to match how our models work
        imageAnalyzer =
                new ImageAnalysis.Builder()
                        .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                        .setTargetRotation(view_finder.getDisplay().getRotation())
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .build();
        // The analyzer can then be assigned to the instance

        imageAnalyzer.setAnalyzer(cameraExecutor, new ImageAnalysis.Analyzer() {
            @Override
            public void analyze(@NonNull ImageProxy image) {
                if (bitmapBuffer == null) {
                    // The image rotation and RGB image buffer are initialized only once
                    // the analyzer has started running
                    bitmapBuffer = Bitmap.createBitmap(
                            image.getWidth(),
                            image.getHeight(),
                            Bitmap.Config.ARGB_8888
                    );
                }

                detectObjects(image);
            }
        });

        // Must unbind the use-cases before rebinding them
        cameraProvider.unbindAll();

        try {
            // A variable number of use-cases can be passed here -
            // camera provides access to CameraControl & CameraInfo
            camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalyzer);

            // Attach the viewfinder's surface provider to preview use case
            if (preview != null) {
                preview.setSurfaceProvider(view_finder.getSurfaceProvider());
            }

        } catch (Exception exc) {
            Log.e(TAG, "Use case binding failed", exc);
        }
    }
    private void initBottomSheetControls() {
        // When clicked, lower detection score threshold floor

        findViewById(R.id.threads_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detectorHelper.threshold >= 0.1) {
                    detectorHelper.threshold -= 0.1f;
                    updateControlsUi();
                }
            }
        });

        // When clicked, raise detection score threshold floor
        findViewById(R.id.threads_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detectorHelper.threshold <= 0.8) {
                    detectorHelper.threshold += 0.1f;
                    updateControlsUi();
                }
            }
        });

        // When clicked, reduce the number of objects that can be detected at a time
        findViewById(R.id.max_results_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detectorHelper.maxResults > 1) {
                    detectorHelper.maxResults--;
                    updateControlsUi();
                }
            }
        });

        // When clicked, increase the number of objects that can be detected at a time
        findViewById(R.id.max_results_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detectorHelper.maxResults < 5) {
                    detectorHelper.maxResults++;
                    updateControlsUi();
                }
            }
        });

        // When clicked, decrease the number of threads used for detection
        findViewById(R.id.threads_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detectorHelper.numThreads > 1) {
                    detectorHelper.numThreads--;
                    updateControlsUi();
                }
            }
        });

        // When clicked, increase the number of threads used for detection
        findViewById(R.id.threads_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detectorHelper.numThreads < 4) {
                    detectorHelper.numThreads++;
                    updateControlsUi();
                }
            }
        });

        // When clicked, change the underlying hardware used for inference. Current options are CPU
        // GPU, and NNAPI
        ((Spinner) findViewById(R.id.spinner_delegate)).setSelection(0, false);
        ((Spinner) findViewById(R.id.spinner_delegate))
                .setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        detectorHelper.currentDelegate = position;
                        updateControlsUi();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

        // When clicked, change the underlying model used for object detection
        ((Spinner) findViewById(R.id.spinner_model)).setSelection(0, false);
        ((Spinner) findViewById(R.id.spinner_model))
                .setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        detectorHelper.currentModel = position;
                        updateControlsUi();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
    }
    private void updateControlsUi() {
        ((TextView) findViewById(R.id.max_results_value)).setText(String.valueOf(detectorHelper.maxResults));
        ((TextView) findViewById(R.id.threshold_value)).setText(String.format("%.2f", detectorHelper.threshold));
        ((TextView) findViewById(R.id.threads_value)).setText(String.valueOf(detectorHelper.numThreads));

        // Needs to be cleared instead of reinitialized because the GPU
        // delegate needs to be initialized on the thread using it when applicable
        detectorHelper.clearObjectDetector();
        ((OverlayView) findViewById(R.id.overlay)).clear();
    }
    private void detectObjects(ImageProxy image) {
        // Copy out RGB bits to the shared bitmap buffer
        if (bitmapBuffer == null) {
            return;
        }
        bitmapBuffer.copyPixelsFromBuffer(image.getPlanes()[0].getBuffer());
        image.close();

        int imageRotation = image.getImageInfo().getRotationDegrees();
        // Pass Bitmap and rotation to the object detector helper for processing and detection
        detectorHelper.detect(bitmapBuffer, imageRotation);
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (imageAnalyzer != null)
            imageAnalyzer.setTargetRotation(findViewById(R.id.view_finder).getDisplay().getRotation());
    }
    @Override public void onResume() {
        super.onResume();
        // Make sure that all permissions are still present, since the
        // user could have removed them while the app was in paused state.
        if (!PermissionActivity.hasPermissions(this)) {
            startActivity(new Intent(MainActivity.this, PermissionActivity.class));
        }
    }
    @Override public void onDestroy() {
        // Shut down our background executor
        cameraExecutor.shutdown();

        super.onDestroy();
    }
    @Override public void onError(String error) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, error, Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override public void onResults(List<Detection> results, long inferenceTime,
                                    int imageHeight, int imageWidth) {

        Function.add_notification(results, location);

        runOnUiThread(() -> {

            // Pass necessary information to OverlayView for drawing on the canvas
            ((OverlayView) findViewById(R.id.overlay)).setResults(
                    results,
                    imageHeight,
                    imageWidth
            );

            // Force a redraw
            ((OverlayView) findViewById(R.id.overlay)).invalidate();

        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_tf);

        detectorHelper = new DetectorHelper( this,this);

        FloatingActionButton fab = findViewById(R.id.am_settings);
        fab.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SettingActivity.class)));

        // Initialize our background executor
        cameraExecutor = Executors.newSingleThreadExecutor();

        // Wait for the views to be properly laid out
        findViewById(R.id.view_finder).post(new Runnable() {
            @Override
            public void run() {
                setUpCamera();
            }
        });


        LocationManager locationManager = (LocationManager) this.getSystemService(Activity.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {

            startActivity(new Intent(MainActivity.this, PermissionActivity.class));
            return;
        }
        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (location == null){
            location = new Location(LocationManager.GPS_PROVIDER);
            location.setLatitude(0);
            location.setLongitude(0);
        }

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                1000, 1f, new LocationListener() {
                    @Override
                    public void onLocationChanged(@NonNull Location location) {
                        MainActivity.this.location = location;
                        System.out.printf("%f : %f", location.getLatitude(), location.getLongitude());
                    }
                });

    }
    @Override public void onBackPressed() {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
            finishAfterTransition();
        } else {
            super.onBackPressed();
        }
    }
}
