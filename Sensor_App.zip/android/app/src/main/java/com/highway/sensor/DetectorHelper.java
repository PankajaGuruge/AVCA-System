package com.highway.sensor;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.SystemClock;

import org.tensorflow.lite.gpu.CompatibilityList;
import org.tensorflow.lite.support.image.ImageProcessor;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.task.core.BaseOptions;
import org.tensorflow.lite.task.vision.detector.Detection;
import org.tensorflow.lite.task.vision.detector.ObjectDetector;
import org.tensorflow.lite.support.image.ops.Rot90Op;

import java.io.IOException;
import java.util.List;

public class DetectorHelper {

    public static final int DELEGATE_CPU = 0;
    public static final int DELEGATE_GPU = 1;
    public static final int  DELEGATE_NNAPI = 2;
    public static final int  MODEL_MOBILENETV1 = 0;
    public static final int MODEL_EFFICIENTDETV0 = 1;
    public static final int MODEL_EFFICIENTDETV1 = 2;
    public static final int MODEL_EFFICIENTDETV2 = 3;


    public float threshold = 0.5f;
    public int numThreads = 2;
    public int maxResults = 3;
    public int currentDelegate = 0;
    public int currentModel = 0;
    Context context;
    DetectorListener objectDetectorListener;

    public DetectorHelper(
            Context context, DetectorListener objectDetectorListener) {
        this.context = context;
        this.objectDetectorListener = objectDetectorListener;
    }

    private ObjectDetector objectDetector = null;

    public void clearObjectDetector() {
        objectDetector = null;
    }

    public void detect(Bitmap image, int imageRotation) {
        if (objectDetector == null) {
            setupObjectDetector();
        }

        // Inference time is the difference between the system time at the start and finish of the
        // process
        long inferenceTime = SystemClock.uptimeMillis();

        // Create preprocessor for the image.
        // See https://www.tensorflow.org/lite/inference_with_metadata/
        //            lite_support#imageprocessor_architecture
        ImageProcessor imageProcessor =
                new ImageProcessor.Builder()
                        .add(new Rot90Op(-imageRotation / 90))
                        .build();

        // Preprocess the image and convert it into a TensorImage for detection.
        TensorImage tensorImage = imageProcessor.process(TensorImage.fromBitmap(image));

        List<Detection> results = objectDetector.detect(tensorImage);
        inferenceTime = SystemClock.uptimeMillis() - inferenceTime;
        objectDetectorListener.onResults(
                results,
                inferenceTime,
                tensorImage.getHeight(),
                tensorImage.getWidth());
    }

    private void setupObjectDetector() {
        // Create the base options for the detector using specifies max results and score threshold
        ObjectDetector.ObjectDetectorOptions.Builder optionsBuilder = ObjectDetector.ObjectDetectorOptions.builder()
                .setScoreThreshold(threshold)
                .setMaxResults(maxResults);

        // Set general detection options, including number of used threads
        BaseOptions.Builder baseOptionsBuilder = BaseOptions.builder().setNumThreads(numThreads);

        // Use the specified hardware for running the model. Default to CPU
        // Use the specified hardware for running the model. Default to CPU
        if (currentDelegate == DELEGATE_CPU) {
            // Default
        }
        else if (currentDelegate == DELEGATE_GPU) {
            if (new CompatibilityList().isDelegateSupportedOnThisDevice()) {
                baseOptionsBuilder.useGpu();
            } else {
                objectDetectorListener.onError("GPU is not supported on this device");
            }
        }
        else if (currentDelegate == DELEGATE_NNAPI) {
            baseOptionsBuilder.useNnapi();
        }

        optionsBuilder.setBaseOptions(baseOptionsBuilder.build());

        String modelName;

        switch (currentModel) {
            case MODEL_MOBILENETV1:
                modelName = "mobilenetv1.tflite";
                break;
            case MODEL_EFFICIENTDETV0:
                modelName = "efficientdet-lite0.tflite";
                break;
            case MODEL_EFFICIENTDETV1:
                modelName = "efficientdet-lite1.tflite";
                break;
            case MODEL_EFFICIENTDETV2:
                modelName = "efficientdet-lite2.tflite";
                break;
            default:
                modelName = "mobilenetv1.tflite";
                break;
        }

        try {
            objectDetector =
                    ObjectDetector.createFromFileAndOptions(context, modelName, optionsBuilder.build());
        } catch (IllegalStateException | IOException e) {
            objectDetectorListener.onError(
                    "Object detector failed to initialize. See error logs for details"
            );
        }
    }

    public interface DetectorListener {
        void onError(String error);
        void onResults(
                List<Detection> results, long inferenceTime,
                int imageHeight, int imageWidth
        );
    }

}
