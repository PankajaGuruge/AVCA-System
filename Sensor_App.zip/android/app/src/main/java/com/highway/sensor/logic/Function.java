package com.highway.sensor.logic;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.highway.sensor.entity.Notification;
import com.highway.sensor.entity.User;

import org.tensorflow.lite.support.label.Category;
import org.tensorflow.lite.task.vision.detector.Detection;

import java.net.URL;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Function {

    private static FirebaseDatabase database;
    private static FirebaseAuth mAuth;
    private static User user;

    private static final String STORAGE_URL = "gs://highway-vehicle.appspot.com";
    private static final String REALTIME_URL = "https://highway-vehicle-default-rtdb.firebaseio.com/";

    public static boolean send_notify = true;
    public static float min_acc = 0;
    public static int interval = 60; // seconds
    private static List<String> labels ;

    public static void setup(Context context){
        FirebaseApp.initializeApp(context);
        mAuth = FirebaseAuth.getInstance();

        database = FirebaseDatabase.getInstance(REALTIME_URL);

        labels = Arrays.asList("dog", "cat", "peacock", "cow", "elephant", "monkey");

        SharedPreferences preferences = context.getSharedPreferences("settings", Context.MODE_PRIVATE);
        send_notify = preferences.getBoolean("send", true);
        min_acc = preferences.getFloat("min", 0);
        interval = preferences.getInt("time", 60);
    }

    public static void save_settings(boolean send, float min, int time, Context context){
        send_notify = send;
        min_acc = min;
        interval = time;

        SharedPreferences.Editor editor = context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit();
        editor.putBoolean("send", send);
        editor.putFloat("min", min);
        editor.putInt("time", time);
        editor.apply();
    }

    public static void login(String username, String password,
                             Response response, Activity activity){
        String email = User.getEmail(username);
        try {
            login_email(email, password, response, activity);
        }
        catch (Exception e) {
            response.response(false, "Unable find account!");
            e.printStackTrace();
        }

    }
    public static void login_email(String email, String password,
                                   Response response, Activity activity){

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(activity, task -> {
                    String uid = mAuth.getUid();
                    if (task.isSuccessful() && uid != null) {

                        database.getReference().child("user").child("info")
                                .child(uid)
                                .addListenerForSingleValueEvent(
                                        new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        user = dataSnapshot.getValue(User.class);
                                        if (user == null) {
                                            response.response(false, "Unknown error occurred!");
                                            return;
                                        }

                                        String[] path = {user.uid, "profile.png"};
                                        new downloadPng(path, activity) {
                                            @Override
                                            public void on_loaded(@Nullable Bitmap... bitmap) {
                                                user.image = bitmap == null ? null : bitmap[0];
                                                response.response(true, "Successfully logged in!");
                                            }
                                        };
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        response.response(false, "Unknown error occurred!");
                                    }
                                }
                                );


                    }
                    else {
                        response.response(false, "Please check your credentials!");
                    }
                });

    }

    public static User getUser() {
        return user;
    }


    static long last = 0;
    public static void add_notification(List<Detection> results, Location location) {
        if (send_notify){
            long now = new Date().getTime();
            if ((now - last) > (interval * 1000L)) {
                for (Detection result : results) {
                    for (Category category : result.getCategories()) {
                        if (labels.contains(category.getLabel()) && category.getScore() > min_acc){
                            last = now;
                            add_notification(category.getLabel(), location.getLatitude(), location.getLongitude());
                            return;
                        }
                    }
                }
            }
        }
    }


    private static abstract class downloadPng {
        public downloadPng(String[] path, Activity activity){
            FirebaseStorage storage = FirebaseStorage.getInstance();
            // Create a storage reference from our app
            StorageReference reference = storage.getReferenceFromUrl(STORAGE_URL);

            for (String child_name : path) {
                reference = reference.child(child_name);
            }

            Task<Uri> downloadUrl = reference.getDownloadUrl();
            downloadUrl.addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()){
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    URL url = new URL(task.getResult().toString());
                                    Bitmap bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            on_loaded(bitmap);
                                        }
                                    });

                                } catch (Exception e) {
                                    e.printStackTrace();
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            on_loaded(null);
                                        }
                                    });

                                }

                            }
                        }).start();
                    }else {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                on_loaded(null);
                            }
                        });
                    }


                }
            });
        }
        public downloadPng(Activity activity, @NonNull List<String> urls){
            new Thread(() -> {
                Bitmap[] bitmaps = new Bitmap[urls.size()];

                for (int i = 0; i < bitmaps.length; i++) {
                    try {
                        URL url = new URL(urls.get(i));
                        bitmaps[i] = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                activity.runOnUiThread(() -> on_loaded(bitmaps));

            }).start();
        }

        public abstract void on_loaded(@Nullable Bitmap... bitmap);

    }

    public static void add_notification(String label, double lat, double lon){
        DatabaseReference push = database.getReference().child("notification").child(user.uid).push();
        Notification notification = new Notification(new Date().getTime(), label, lat, lon);
        notification.id = push.getKey();
        notification.message = "There is a " + label + " near " + lat + ", " + lon;
        push.setValue(notification);
    }

}
