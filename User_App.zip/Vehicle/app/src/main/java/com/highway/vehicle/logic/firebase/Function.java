package com.highway.vehicle.logic.firebase;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.highway.vehicle.entity.Notification;
import com.highway.vehicle.entity.User;

import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Function {

    private static FirebaseDatabase database;
    private static FirebaseAuth mAuth;
    private static User user;
    public static boolean english = true;
    public static List<Notification> notifications = new ArrayList<>();

    private static final String STORAGE_URL = "gs://highway-vehicle.appspot.com";
    private static final String REALTIME_URL = "https://highway-vehicle-default-rtdb.firebaseio.com/";

    public static void setup(Context context){
        FirebaseApp.initializeApp(context);
        mAuth = FirebaseAuth.getInstance();

        database = FirebaseDatabase.getInstance(REALTIME_URL);

    }

    public static void login(String username, String password,
                             Response response, Activity activity){
        String email = User.getEmail(username);
        try {
            login_email(email, password, response, activity);
        }
        catch (Exception e) {
            response.response(false, "Unable find account!");
            e.printStackTrace();
        }

    }
    public static void login_email(String email, String password,
                                   Response response, Activity activity){

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(activity, task -> {
                    String uid = mAuth.getUid();
                    if (task.isSuccessful() && uid != null) {

                        database.getReference().child("user").child("info")
                                .child(uid)
                                .addListenerForSingleValueEvent(
                                        new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        user = dataSnapshot.getValue(User.class);
                                        if (user == null) {
                                            response.response(false, "Unknown error occurred!");
                                            return;
                                        }

                                        String[] path = {user.uid, "profile.png"};
                                        new downloadPng(path, activity) {
                                            @Override
                                            public void on_loaded(@Nullable Bitmap... bitmap) {
                                                user.image = bitmap == null ? null : bitmap[0];
                                                response.response(true, "Successfully logged in!");
                                            }
                                        };
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        response.response(false, "Unknown error occurred!");
                                    }
                                }
                                );


                    }
                    else {
                        response.response(false, "Please check your credentials!");
                    }
                });

    }
    public static void register_basic(User user, String password, Bitmap bitmap,
                                      Response response, Activity activity){

        if (user.username.length() < 5){
            response.response(false, "Username should at least be 5 characters.");
        }
        if (!user.username.matches("[a-zA-Z0-9]+")){
            response.response(false, "Invalid username!");
        }

        database.getReference().child("user").child("username-uid")
                .child(user.username)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String id = null;
                try {
                    id = dataSnapshot.getValue(String.class);
                }
                catch (Exception f) {
                    f.printStackTrace();
                }

                if (id != null){
                    response.response(false, "Username is taken!");
                }
                else {
                    mAuth.createUserWithEmailAndPassword(user.getEmail(), password)
                            .addOnCompleteListener(activity, task -> {
                                if (task.isSuccessful()) {

                                    FirebaseUser u = mAuth.getCurrentUser();
                                    if (u == null){
                                        response.response(false, "Unknown error occurred!");
                                        return;
                                    }

                                    user.uid = (u.getUid());
                                    database.getReference().child("user").child("username-uid")
                                            .child(user.username).setValue(u.getUid());
                                    database.getReference().child("user").child("info")
                                            .child(u.getUid()).setValue(user);
                                    Function.user = user;
                                    if (bitmap != null){
                                        upload(bitmap, u.getUid(), response);
                                    }
                                    else {
                                        response.response(true, "Account was created!");
                                    }

                                }
                                else {
                                    response.response(false, "Please check your details!");
                                }
                            });
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                response.response(false, "Unknown error occurred!");
            }
        });


    }

    public abstract static class verify_phone{

        private String mVerificationId;
        private PhoneAuthProvider.ForceResendingToken mResendToken;
        private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
        private String mobile;
        private final Activity activity;

        public verify_phone(Activity activity) {
            this.activity = activity;
            setup_call_backs();

        }
        public void send_verification(String mobile){
            this.mobile = mobile;
            startPhoneNumberVerification(mobile);
        }
        public void verify(String code){
            verifyPhoneNumberWithCode(mVerificationId, code);
        }
        public void resend_code(){
            if (mResendToken != null){
                resendVerificationCode(mobile, mResendToken);
            }
        }

        private static final String TAG = "PhoneAuthActivity";

        private void setup_call_backs(){
            mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                @Override
                public void onVerificationCompleted(PhoneAuthCredential credential) {
                    onCredential(credential);
                }

                @Override
                public void onVerificationFailed(FirebaseException e) {
                    // This callback is invoked in an invalid request for verification is made,
                    // for instance if the the phone number format is not valid.
                    Log.w(TAG, "onVerificationFailed", e);

                    if (e instanceof FirebaseAuthInvalidCredentialsException) {
                        // Invalid request
                    } else if (e instanceof FirebaseTooManyRequestsException) {
                        // The SMS quota for the project has been exceeded
                    }

                    error("Try again later!");
                }

                @Override
                public void onCodeSent(@NonNull String verificationId,
                                       @NonNull PhoneAuthProvider.ForceResendingToken token) {
                    // The SMS verification code has been sent to the provided phone number, we
                    // now need to ask the user to enter the code and then construct a credential
                    // by combining the code with a verification ID.
                    Log.d(TAG, "onCodeSent:" + verificationId);

                    // Save verification ID and resending token so we can use them later
                    mVerificationId = verificationId;
                    mResendToken = token;
                }
            };
        }

        private void startPhoneNumberVerification(String phoneNumber) {
            // [START start_phone_auth]
            PhoneAuthOptions options =
                    PhoneAuthOptions.newBuilder(mAuth)
                            .setPhoneNumber(phoneNumber)       // Phone number to verify
                            .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                            .setActivity(activity)                 // Activity (for callback binding)
                            .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                            .build();
            PhoneAuthProvider.verifyPhoneNumber(options);
            // [END start_phone_auth]
        }

        private void verifyPhoneNumberWithCode(String verificationId, String code) {
            // [START verify_with_code]
            PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
            onCredential(credential);
        }

        private void resendVerificationCode(String phoneNumber,
                                            PhoneAuthProvider.ForceResendingToken token) {
            PhoneAuthOptions options =
                    PhoneAuthOptions.newBuilder(mAuth)
                            .setPhoneNumber(phoneNumber)       // Phone number to verify
                            .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                            .setActivity(activity)                 // Activity (for callback binding)
                            .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                            .setForceResendingToken(token)     // ForceResendingToken from callbacks
                            .build();
            PhoneAuthProvider.verifyPhoneNumber(options);
        }

        public abstract void error(String error);
        public abstract void onCredential(PhoneAuthCredential credential);



    }

    public static abstract class update_profile {

        public update_profile(String full_name, String address, String phone){
            User user = Function.user;
            user.full_name = full_name;
            user.address = address;
            user.mobile = phone;

            getReference(new String[]{"user", "info", user.uid}).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()){
                        done();
                    }else {
                        failure();
                    }
                }
            });
        }

        public abstract void done();
        public abstract void failure();
    }

    public static abstract class update_profile_image{

        public update_profile_image(Bitmap bitmap) {
            if (bitmap != null) {
                String[] path = {user.uid, "profile.png"};
                new uploadPng(path, bitmap) {
                    @Override
                    public void done(boolean success) {
                        if (success) update_profile_image.this.done();
                        else failure();
                    }
                };

            }
        }

        public abstract void done();
        public abstract void failure();


    }

    public static class NotificationManager {
        public NotificationManager() {
            String uid = user.uid;
            DatabaseReference reference = getReference("notification", uid);

            ChildEventListener listener = new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                    Notification notification = snapshot.getValue(Notification.class);
                    if (notification != null) {
                        notification.id = snapshot.getKey();
                        on(notification);
                    }

                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            };
            reference.addChildEventListener(listener);
        }
        public void on(Notification notification){

        }
    }


    public static User getUser() {
        return user;
    }

    private static void upload(Bitmap bitmap, String id, Response response){

        String[] path = {id, "profile.png"};
        new uploadPng(path, bitmap) {
            @Override
            public void done(boolean success) {
                response.response(success, success ? "" : "Unable to upload image!");
            }
        };

    }


    private static abstract class downloadPng {
        public downloadPng(String[] path, Activity activity){
            FirebaseStorage storage = FirebaseStorage.getInstance();
            // Create a storage reference from our app
            StorageReference reference = storage.getReferenceFromUrl(STORAGE_URL);

            for (String child_name : path) {
                reference = reference.child(child_name);
            }

            Task<Uri> downloadUrl = reference.getDownloadUrl();
            downloadUrl.addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()){
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    URL url = new URL(task.getResult().toString());
                                    Bitmap bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            on_loaded(bitmap);
                                        }
                                    });

                                } catch (Exception e) {
                                    e.printStackTrace();
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            on_loaded(null);
                                        }
                                    });

                                }

                            }
                        }).start();
                    }else {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                on_loaded(null);
                            }
                        });
                    }


                }
            });
        }
        public downloadPng(Activity activity, @NonNull List<String> urls){
            new Thread(() -> {
                Bitmap[] bitmaps = new Bitmap[urls.size()];

                for (int i = 0; i < bitmaps.length; i++) {
                    try {
                        URL url = new URL(urls.get(i));
                        bitmaps[i] = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                activity.runOnUiThread(() -> on_loaded(bitmaps));

            }).start();
        }

        public abstract void on_loaded(@Nullable Bitmap... bitmap);

    }
    private static abstract class uploadPng{
        public uploadPng(@NonNull String[] path, Bitmap bitmap) {
            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference reference = storage.getReferenceFromUrl(STORAGE_URL);

            for (String child : path) {
                reference = reference.child(child);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data = baos.toByteArray();

            UploadTask uploadTask = reference.putBytes(data);
            StorageReference finalReference = reference;
            uploadTask
                    .addOnFailureListener(exception -> done(false))
                    .addOnSuccessListener(taskSnapshot -> {
                        finalReference.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                if (task.isSuccessful()){
                                    Uri uri = task.getResult();
                                    url(uri.toString());
                                }
                                else {
                                    url(null);
                                }
                            }
                        });
                        done(true);
                    });
        }

        public void url(@Nullable String url){

        }

        public abstract void done(boolean success);
    }

    private static DatabaseReference getReference(@NonNull String... children){
        DatabaseReference reference = database.getReference();

        for (String child : children) {
            reference = reference.child(child);
        }

        return reference;
    }


}
