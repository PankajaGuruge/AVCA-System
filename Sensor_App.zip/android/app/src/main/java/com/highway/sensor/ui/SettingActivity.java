package com.highway.sensor.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.highway.sensor.R;
import com.highway.sensor.logic.Function;

public class SettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        SwitchCompat switchCompat = findViewById(R.id.as_send_notify);
        EditText min = findViewById(R.id.as_accuracy);
        EditText tim = findViewById(R.id.as_time);

        switchCompat.setChecked(Function.send_notify);
        min.setText(String.valueOf(Function.min_acc));
        tim.setText(String.valueOf(Function.interval));

        FloatingActionButton fab = findViewById(R.id.as_save);
        fab.setOnClickListener(v -> {
            boolean send = switchCompat.isChecked();
            float m;
            try {
                m = Float.parseFloat(min.getText().toString());
            } catch (NumberFormatException e) {
                Toast.makeText(SettingActivity.this, "Invalid minimum accuracy!", Toast.LENGTH_SHORT).show();
                return;
            }
            int t;
            try {
                t = Integer.parseInt(tim.getText().toString());
            } catch (NumberFormatException e) {
                Toast.makeText(SettingActivity.this, "Invalid time interval!", Toast.LENGTH_SHORT).show();
                return;
            }
            Function.save_settings(send, m, t,SettingActivity.this);
            Toast.makeText(SettingActivity.this, "Settings were saved!", Toast.LENGTH_SHORT).show();
            finish();
        });

    }
}