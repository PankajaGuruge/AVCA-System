package com.highway.vehicle;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.highway.vehicle.entity.Notification;
import com.highway.vehicle.logic.firebase.Function;
import com.highway.vehicle.ui.activity.HomeActivity;

public class NotificationService extends Service {
    public static final String NORMAL_CHANNEL_ID = "Notification";
    private static final String PERMANENT_CHANNEL_ID = "Permanent";
    private static int NOTIFIED_ID = 2;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        startForeground();
        listen();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);


        return START_STICKY;
    }

    private void listen(){
        new Function.NotificationManager() {
            @Override
            public void on(Notification notify) {
                Intent notificationIntent = new Intent(NotificationService.this, HomeActivity.class);
                PendingIntent pendingIntent = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    pendingIntent = PendingIntent.getActivity(NotificationService.this, 0,
                            notificationIntent, PendingIntent.FLAG_MUTABLE);
                } else {
                    pendingIntent = PendingIntent.getActivity(NotificationService.this, 0,
                            notificationIntent, 0);
                }

                Function.notifications.add(notify);
                if (HomeActivity.adapter != null){
                    HomeActivity.adapter.notifyDataSetChanged();
                }

                android.app.Notification notification =
                        new NotificationCompat.Builder(NotificationService.this,
                                NORMAL_CHANNEL_ID) // don't forget create a notification channel first
                                .setSmallIcon(R.drawable.app_logo)
                                .setContentTitle(notify.get_title())
                                .setContentText(notify.message)
                                .setContentIntent(pendingIntent)
                                .build();

                NotificationManagerCompat compat = NotificationManagerCompat.from(NotificationService.this);
                compat.notify(NOTIFIED_ID++, notification);
            }
        };

    }

    private void startForeground() {
        Intent notificationIntent = new Intent(this, HomeActivity.class);

        PendingIntent pendingIntent;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            pendingIntent = PendingIntent.getActivity(NotificationService.this, 0,
                    notificationIntent, PendingIntent.FLAG_MUTABLE);
        }else {
            pendingIntent = PendingIntent.getActivity(NotificationService.this, 0,
                    notificationIntent, 0);
        }

        android.app.Notification notification =  new NotificationCompat.Builder(this,
                PERMANENT_CHANNEL_ID) // don't forget create a notification channel first
                .setOngoing(true)
                .setSmallIcon(R.drawable.app_logo)
                .setContentTitle(getString(R.string.app_name))
                .setContentText("Listening to new notifications in background.")
                .setContentIntent(pendingIntent)
                .setSilent(true)
                .build();

        startForeground(1, notification);
    }

}