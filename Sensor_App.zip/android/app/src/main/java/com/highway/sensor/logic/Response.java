package com.highway.sensor.logic;

public abstract class Response {

    public abstract void response(boolean success, String message);
}
