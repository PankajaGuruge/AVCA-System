package com.highway.vehicle.ui.activity.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.highway.vehicle.R;
import com.highway.vehicle.logic.Sanitize;
import com.highway.vehicle.logic.Validation;
import com.highway.vehicle.logic.firebase.Function;
import com.highway.vehicle.ui.activity.HomeActivity;

public class ConfirmActivity extends AppCompatActivity {

    boolean first = true;
    String mobile;
    Function.verify_phone verify_phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mobile = getIntent().getStringExtra("mobile");

        assert mobile != null;

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.pre_app_background));


        setContentView(R.layout.activity_pre_forgot_reset_password);

        TextView reset_tv = findViewById(R.id.textView2);
        reset_tv.setText(R.string.verify_number);

        EditText phone = findViewById(R.id.apfrp_username);
        phone.setText(mobile);

        verify_phone = new Function.verify_phone(this) {
            @Override
            public void error(String error) {
                Toast.makeText(ConfirmActivity.this, error, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCredential(PhoneAuthCredential credential) {
                FirebaseAuth instance = FirebaseAuth.getInstance();
                FirebaseUser user = instance.getCurrentUser();
                if (user != null){
                    user.linkWithCredential(credential);
                    Intent intent = new Intent(ConfirmActivity.this, HomeActivity.class);
                    startActivity(intent);
                    return;
                }

                Toast.makeText(ConfirmActivity.this,
                        getString(R.string.unknown_error_occurred), Toast.LENGTH_SHORT).show();
            }
        };

        Button reset = findViewById(R.id.apfrp_reset);
        reset.setOnClickListener(v -> {
            String mobile = phone.getText().toString();
            if (Validation.phone(mobile)){
                send_verification(Sanitize.phone(mobile));
            }else {
                Toast.makeText(ConfirmActivity.this,
                        getString(R.string.invalid_mobile_number),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void send_verification(String mobile){
        this.mobile = mobile;
        verify_phone.send_verification(mobile);

        setContentView(R.layout.activity_pre_forgot_verify);

        TextView title = findViewById(R.id.textView2);
        TextView sub_title = findViewById(R.id.textView4);

        title.setText(R.string.verify_your_number);
        sub_title.setText(getString(R.string.please_enter_6_digit_code_sent_to, mobile));

        Button verify = findViewById(R.id.apfv_verify);
        verify.setOnClickListener(v -> {
            EditText v_1 = findViewById(R.id.apfv_1);
            EditText v_2 = findViewById(R.id.apfv_2);
            EditText v_3 = findViewById(R.id.apfv_3);
            EditText v_4 = findViewById(R.id.apfv_4);
            EditText v_5 = findViewById(R.id.apfv_5);
            EditText v_6 = findViewById(R.id.apfv_6);

            String c_1 = v_1.getText().toString();
            String c_2 = v_2.getText().toString();
            String c_3 = v_3.getText().toString();
            String c_4 = v_4.getText().toString();
            String c_5 = v_5.getText().toString();
            String c_6 = v_6.getText().toString();

            String code = c_1 + c_2 + c_3 + c_4 + c_5 + c_6;
            if (code.length() < 6 || code.matches("[0-9]")){
                Toast.makeText(ConfirmActivity.this, getString(R.string.invalid_code), Toast.LENGTH_SHORT).show();
                return;
            }

            verify_phone.verify(code);
        });

        TextView resend = findViewById(R.id.apfv_resend);
        resend.setOnClickListener(v -> {
            verify_phone.resend_code();
        });


    }

}























/*
package com.project.crops.ui.activity.pre_login;

        import android.content.Intent;
        import android.graphics.Color;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.view.Window;
        import android.view.WindowManager;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;

        import com.google.android.gms.tasks.OnCompleteListener;
        import com.google.android.gms.tasks.Task;
        import com.google.firebase.FirebaseException;
        import com.google.firebase.FirebaseTooManyRequestsException;
        import com.google.firebase.auth.AuthResult;
        import com.google.firebase.auth.FirebaseAuth;
        import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
        import com.google.firebase.auth.FirebaseUser;
        import com.google.firebase.auth.PhoneAuthCredential;
        import com.google.firebase.auth.PhoneAuthOptions;
        import com.google.firebase.auth.PhoneAuthProvider;
        import com.project.crops.R;
        import com.project.crops.logic.Sanitize;
        import com.project.crops.logic.Validation;
        import com.project.crops.ui.activity.home.HomeActivity;

        import java.util.concurrent.TimeUnit;

public class ConfirmActivity extends AppCompatActivity {

    boolean first = true;
    String mobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mobile = getIntent().getStringExtra("mobile");

        assert mobile != null;

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.parseColor("#042519"));


        setContentView(R.layout.activity_pre_forgot_reset_password);

        TextView reset_tv = findViewById(R.id.textView2);
        reset_tv.setText("Confirm your mobile number");

        EditText phone = findViewById(R.id.apfrp_username);
        phone.setText(mobile);

        Button reset = findViewById(R.id.apfrp_reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mobile = phone.getText().toString();
                if (Validation.phone(mobile)){
                    send_verification(Sanitize.phone(mobile));
                }else {
                    Toast.makeText(ConfirmActivity.this, "Invalid mobile number!", Toast.LENGTH_SHORT).show();
                }
            }
        });




        mAuth = FirebaseAuth.getInstance();
        // [END initialize_auth]

        // Initialize phone auth callbacks
        // [START phone_auth_callbacks]
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
                // This callback will be invoked in two situations:
                // 1 - Instant verification. In some cases the phone number can be instantly
                //     verified without needing to send or enter a verification code.
                // 2 - Auto-retrieval. On some devices Google Play services can automatically
                //     detect the incoming verification SMS and perform verification without
*/
/*                //     user action.
                Log.d(TAG, "onVerificationCompleted:" + credential);

                signInWithPhoneAuthCredential(credential);*//*

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                // This callback is invoked in an invalid request for verification is made,
                // for instance if the the phone number format is not valid.
                Log.w(TAG, "onVerificationFailed", e);

                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                    // Invalid request
                } else if (e instanceof FirebaseTooManyRequestsException) {
                    // The SMS quota for the project has been exceeded
                }

                Toast.makeText(ConfirmActivity.this, "Try again later!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCodeSent(@NonNull String verificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                // The SMS verification code has been sent to the provided phone number, we
                // now need to ask the user to enter the code and then construct a credential
                // by combining the code with a verification ID.
                Log.d(TAG, "onCodeSent:" + verificationId);

                // Save verification ID and resending token so we can use them later
                mVerificationId = verificationId;
                mResendToken = token;
            }
        };

    }

    private void send_verification(String mobile){
        this.mobile = mobile;
        startPhoneNumberVerification(mobile);
        setContentView(R.layout.activity_pre_forgot_verify);

        Button verify = findViewById(R.id.apfv_verify);
        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText v_1 = findViewById(R.id.apfv_1);
                EditText v_2 = findViewById(R.id.apfv_2);
                EditText v_3 = findViewById(R.id.apfv_3);
                EditText v_4 = findViewById(R.id.apfv_4);
                EditText v_5 = findViewById(R.id.apfv_5);
                EditText v_6 = findViewById(R.id.apfv_6);

                String c_1 = v_1.getText().toString();
                String c_2 = v_2.getText().toString();
                String c_3 = v_3.getText().toString();
                String c_4 = v_4.getText().toString();
                String c_5 = v_5.getText().toString();
                String c_6 = v_6.getText().toString();

                String code = c_1 + c_2 + c_3 + c_4 + c_5 + c_6;
                if (code.length() < 6 || code.matches("[0-9]")){
                    Toast.makeText(ConfirmActivity.this, "Invalid code!", Toast.LENGTH_SHORT).show();
                    return;
                }

                verifyPhoneNumberWithCode(mVerificationId, code);
            }
        });

        TextView resend = findViewById(R.id.apfv_resend);
        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mResendToken != null){
                    resendVerificationCode(mobile, mResendToken);
                }
            }
        });


    }


    private static final String TAG = "PhoneAuthActivity";

    // [START declare_auth]
    private FirebaseAuth mAuth;
    // [END declare_auth]

    private String mVerificationId;
    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;


    private void startPhoneNumberVerification(String phoneNumber) {
        // [START start_phone_auth]
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(phoneNumber)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
        // [END start_phone_auth]
    }

    private void verifyPhoneNumberWithCode(String verificationId, String code) {
        // [START verify_with_code]
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null){
            user.linkWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Intent intent = new Intent(ConfirmActivity.this, HomeActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }else {
                        Toast.makeText(ConfirmActivity.this,
                                "Unknown error occurred!", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

        // [END verify_with_code]
    }

    // [START resend_verification]
    private void resendVerificationCode(String phoneNumber,
                                        PhoneAuthProvider.ForceResendingToken token) {
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(phoneNumber)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                        .setForceResendingToken(token)     // ForceResendingToken from callbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }
    // [END resend_verification]

    // [START sign_in_with_phone]
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = task.getResult().getUser();
                            // Update UI
                        }
                        else {

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                            }
                        }
                    }
                });
    }


}
*/
