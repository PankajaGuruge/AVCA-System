package com.highway.sensor.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.highway.sensor.R;
import com.highway.sensor.logic.Function;
import com.highway.sensor.logic.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Function.setup(this);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.pre_app_background));


        Handler handler = new Handler(getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                setContentView(R.layout.activity_pre_login_layout);
                setup();
            }
        }, 2000);

        setContentView(R.layout.activity_pre_splash_layout);
    }

    private void setup(){


        Button login = findViewById(R.id.ll_login);
        login.setOnClickListener(v -> login());

    }

    private void login(){

        EditText un = findViewById(R.id.ll_username);
        EditText pw = findViewById(R.id.ll_password);

        String username = un.getText().toString();
        String password = pw.getText().toString();

        ProgressDialog dialog = ProgressDialog.show(this, getString(R.string.loading), getString(R.string.please_wait));

        Response response = new Response() {
            @Override
            public void response(boolean success, String message) {
                dialog.dismiss();

                if (success) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                }

            }
        };

        Function.login(username, password, response, this);
    }


}