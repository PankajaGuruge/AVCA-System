package com.highway.vehicle.ui.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.utils.widget.ImageFilterView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.highway.vehicle.R;
import com.highway.vehicle.entity.User;
import com.highway.vehicle.logic.Validation;
import com.highway.vehicle.logic.firebase.Function;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ProfileActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> launcher;
    private boolean is_edit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_profile);

        ImageButton back = findViewById(R.id.ap_back);

        back.setOnClickListener(v -> onBackPressed());

        get_images();

        User user = Function.getUser();
        TextView title = findViewById(R.id.ap_title);
        title.setText("Hi,\n" + user.getDisplayName());


        EditText full_name =findViewById(R.id.ap_full_name);
        EditText phone =findViewById(R.id.ap_phone);
        TextView username =findViewById(R.id.ap_username);
        EditText address =findViewById(R.id.ap_address);

        full_name.setText(user.full_name);
        phone.setText(user.mobile);
        username.setText(user.username);
        address.setText(user.address);

        ImageFilterView image = findViewById(R.id.ap_image);
        ImageButton change = findViewById(R.id.ap_change_image);

        if (user.image != null){
            image.setImageBitmap(user.image);
        }

        change.setOnClickListener(v -> {
            request_image(false);
        });

        FloatingActionButton edit = findViewById(R.id.ap_edit);

        enable(full_name, false);
        enable(address, false);
        enable(phone, false);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (is_edit){

                    String fn = full_name.getText().toString();
                    String pn = phone.getText().toString();
                    String add = address.getText().toString();

                    if (pn.length()> 0 && !Validation.phone(pn)){
                        show("Invalid phone number!");
                        return;
                    }

                    if (fn.length() < 3){
                        show("Invalid full name!");
                        return;
                    }
                    ProgressDialog dialog = showDialog();
                    new Function.update_profile(fn, add, pn) {
                        @Override
                        public void done() {
                            show("Profile was updated!");
                            is_edit = false;
                            edit.setImageResource(R.drawable.edit);

                            enable(full_name, false);
                            enable(address, false);
                            enable(phone, false);

                            dialog.dismiss();

                        }

                        @Override
                        public void failure() {
                            show("Unable to update profile!");

                        }
                    };

                }else {
                    enable(full_name, true);
                    enable(address, true);
                    enable(phone, true);

                    is_edit = true;
                    edit.setImageResource(R.drawable.save);

                }

            }
        });

    }

    private void get_images(){
        List<Bitmap> bitmaps = new ArrayList<>();
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        Intent data = result.getData();
                        bitmaps.clear();

                        if (data != null){
                            Bundle extras = data.getExtras();

                            if (extras != null){
                               Bitmap bitmap = (Bitmap) extras.get("data");
                               if (bitmap != null){
                                   bitmaps.add(bitmap);
                               }
                            }else if (data.getClipData() != null) {
                                ClipData clipData = data.getClipData();
                                int cout = clipData.getItemCount();
                                for (int i = 0; i < cout; i++) {
                                    Uri uri = data.getClipData().getItemAt(i).getUri();
                                    try {
                                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                                        bitmaps.add(bitmap);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                            else {
                                Uri uri = data.getData();
                                try {
                                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                                    bitmaps.add(bitmap);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                        }else {
                        }
                    }
                    on_image_received(bitmaps);
                });


    }

    protected void request_image(boolean multiple){
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        dialog.setContentView(R.layout.item_bottom_choose_image);

        ImageView capture = dialog.findViewById(R.id.ibci_camera);
        ImageView choose = dialog.findViewById(R.id.ibci_gallery);

        capture.setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (multiple){
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            dialog.dismiss();
            launcher.launch(intent);
        });
        choose.setOnClickListener(v -> {

            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            if (multiple){
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            dialog.dismiss();
            launcher.launch(intent);
        });

        dialog.show();
    }

    public int getHeight(){
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }
    public int getWidth(){
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }
    protected float dp_to_px(float dip){

        Resources r = getResources();
        float px = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dip,
                r.getDisplayMetrics()
        );
        return px;
    }

    protected void show(String text){
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
    protected ProgressDialog showDialog(){
        return ProgressDialog.show(this, "Loading", "Please wait!");
    }
    protected String capitalize(String text){
        if (text == null || text.length() == 0) return text;
        return text.substring(0, 1).toUpperCase(Locale.ROOT) + text.substring(1);
    }


    private void enable(EditText editText, boolean enable){
        editText.setFocusable(enable);
        editText.setClickable(enable);
        editText.setFocusableInTouchMode(enable);
    }

    protected void on_image_received(List<Bitmap> bitmaps) {
        if (bitmaps.size() == 0){
            show("No image was selected!");
        }else {
            Bitmap bitmap = bitmaps.get(0);
            if (bitmap == null){
                show("Unknown error occurred!");
                return;
            }
            new Function.update_profile_image(bitmap) {
                @Override
                public void done() {
                    ImageFilterView image = findViewById(R.id.ap_image);
                    image.setImageBitmap(bitmap);
                    show("Profile image was successfully updated!");
                }

                @Override
                public void failure() {
                    show("Unable to update profile image!");
                }
            };



        }
    }

}