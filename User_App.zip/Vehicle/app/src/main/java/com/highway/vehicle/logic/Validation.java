package com.highway.vehicle.logic;

import androidx.annotation.Nullable;

public class Validation {

    public static boolean phone(@Nullable String number){
        if (number == null) return false;
        String a =number.replace(" ", "").replace("-", "").replace("+", "");
        if (!a.matches("[0-9]+")){
            return false;
        }

        if (number.length() < 9){
            return false;
        }

        if (number.length() > 12){
            return false;
        }

        return true;
    }

}
