package com.highway.vehicle.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.highway.vehicle.NotificationService;
import com.highway.vehicle.R;
import com.highway.vehicle.entity.Notification;
import com.highway.vehicle.logic.firebase.Function;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    public static BaseAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createNotificationChannel();
        Intent intent = new Intent(this, NotificationService.class);
        startService(intent);

        Button profile = findViewById(R.id.am_button);
        profile.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, ProfileActivity.class)));

        Button clear = findViewById(R.id.am_clear);
        clear.setOnClickListener(v -> {
            Function.notifications.clear();
            adapter.notifyDataSetChanged();
        });

        ListView listView = findViewById(R.id.am_list);
        LayoutInflater inflater = LayoutInflater.from(this);

        List<Notification> notifications = Function.notifications;

        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return notifications.size();
            }

            @Override
            public Object getItem(int position) {
                return notifications.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                Notification notification = notifications.get(position);
                View view = inflater.inflate(R.layout.item_notification, parent, false);
                TextView title = view.findViewById(R.id.in_title);
                TextView content = view.findViewById(R.id.in_content);

                title.setText(notification.get_title());
                content.setText(notification.message);

                return view;
            }
        };
        listView.setAdapter(adapter);



    }

    private void createNotificationChannel() {

        String[] channels = {"Permanent", "Notification"};

        for (String CHANNEL_ID : channels) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                String name = CHANNEL_ID;
                String description = CHANNEL_ID;
                int importance = NotificationManager.IMPORTANCE_DEFAULT;
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
                channel.setDescription(description);
                // Register the channel with the system; you can't change the importance
                // or other notification behaviors after this
                NotificationManager notificationManager = getSystemService(NotificationManager.class);
                notificationManager.createNotificationChannel(channel);
            }
        }
    }


}