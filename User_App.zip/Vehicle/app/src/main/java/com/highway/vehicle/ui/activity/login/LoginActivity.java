package com.highway.vehicle.ui.activity.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.highway.vehicle.R;
import com.highway.vehicle.logic.firebase.Function;
import com.highway.vehicle.logic.firebase.Response;
import com.highway.vehicle.ui.activity.HomeActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Function.setup(this);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.pre_app_background));


        Handler handler = new Handler(getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                setContentView(R.layout.activity_pre_login_layout);
                setup();
            }
        }, 2000);

        setContentView(R.layout.activity_pre_splash_layout);
    }

    private void setup(){
        TextView create = findViewById(R.id.ll_create);
        create.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        Button login = findViewById(R.id.ll_login);
        login.setOnClickListener(v -> login());

        TextView forgot = findViewById(R.id.ll_forgot);
        forgot.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, ForgotActivity.class)));

    }

    private void login(){

        EditText un = findViewById(R.id.ll_username);
        EditText pw = findViewById(R.id.ll_password);

        String username = un.getText().toString();
        String password = pw.getText().toString();

        ProgressDialog dialog = ProgressDialog.show(this, getString(R.string.loading), getString(R.string.please_wait));

        Response response = new Response() {
            @Override
            public void response(boolean success, String message) {
                dialog.dismiss();

                if (success) {
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                }

            }
        };

        Function.login(username, password, response, this);
    }


}