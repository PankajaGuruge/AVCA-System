package com.highway.vehicle.entity;

import com.google.firebase.database.Exclude;

public class Notification {

    public String id;
    public long time;
    public String object;
    public double latitude;
    public double longitude;
    public String message;

    public Notification() {
    }

    public Notification(long time, String object, double latitude, double longitude) {
        this.time = time;
        this.object = object;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    @Exclude
    public String get_title(){
        return "There is a " + object + "!";
    }
    @Exclude
    public String get_content(){
        return message;
    }
}
