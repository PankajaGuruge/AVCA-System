package com.highway.vehicle.logic.firebase;

import com.highway.vehicle.entity.User;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class Request {

    /**
     * Recommend crops, Weather, Disease
     */

    public String user;
    public String type;
    public String language;
    public HashMap<String, String> information;
    public String time;

    public Request() {
    }

    public Request(User user, String type) {
        this.user = user.uid;
        this.type = type;
        this.time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault()).format(new Date());
        information = new HashMap<>();
        language = Function.english ? "English" : "Sinhala";
    }

    public void addInfo(String tag, String info){
        information.put(tag, info);
    }

}
