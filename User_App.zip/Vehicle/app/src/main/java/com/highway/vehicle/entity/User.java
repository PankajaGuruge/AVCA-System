package com.highway.vehicle.entity;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.google.firebase.database.Exclude;

import java.util.Locale;

public class User {

    public String uid;

    @Exclude
    public Bitmap image;

    public String title;
    public String full_name;
    public String username;
    public String address;
    public String district;
    public String mobile;

    @Exclude
    public String password;

    public String vehicle;
    public String licence;

    public User() {
    }

    public User(Bitmap image, String title, String full_name,
                String username, String address, String district,
                String mobile) {
        this.image = image;
        this.title = title;
        this.full_name = full_name;
        this.username = username;
        this.address = address;
        this.district = district;
        this.mobile = mobile;
    }

    public String getEmail(){
        return getEmail(username);
    }

    public String getDisplayName(){

        if (full_name == null && title == null) return "Mr. No name";
        if (full_name == null ) return title + ". No name";
        String first = full_name.split(" ")[0];
        return first;
    }


    public static String getEmail(String username){
        if (username == null) return null;
        String email = username.toLowerCase(Locale.ROOT);
        email = email.replace(" ", "_");
        return email + "@crops.lk";
    }
}
