package com.highway.vehicle.logic.firebase;

public abstract class Response {

    public abstract void response(boolean success, String message);
}
