package com.highway.vehicle.ui.activity.login;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.highway.vehicle.R;
import com.highway.vehicle.entity.User;
import com.highway.vehicle.logic.Validation;
import com.highway.vehicle.logic.firebase.Function;
import com.highway.vehicle.logic.firebase.Response;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.pre_app_background));

        setContentView(R.layout.activity_pre_register_layout);

        Button register = findViewById(R.id.rl_register);
        TextView login = findViewById(R.id.aprl_login);
        login.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
        register.setOnClickListener(v -> setup());

    }

    private void setup(){

        EditText fn = findViewById(R.id.rl_fullname);
        EditText addr = findViewById(R.id.rl_address);
        EditText con = findViewById(R.id.rl_contact);
        EditText un = findViewById(R.id.rl_username);
        EditText lic = findViewById(R.id.rl_licence);
        EditText veh = findViewById(R.id.rl_vehicle);

        EditText pw = findViewById(R.id.rl_password);
        EditText pwc = findViewById(R.id.rl_password_conf);

        String full_name = fn.getText().toString();
        String address = addr.getText().toString();
        String contact = con.getText().toString();
        String username = un.getText().toString();

        String vehicle = veh.getText().toString();
        String licence = lic.getText().toString();



        String password = pw.getText().toString();
        String password_conf = pwc.getText().toString();

        if (!password.equals(password_conf)){
            Toast.makeText(this, "Passwords are not equal!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 6){
            Toast.makeText(this, "Please use a strong password!", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean a = Validation.phone(contact);
        if (!a){
            Toast.makeText(this, "Invalid phone number!", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User(null, null, full_name, username, address, null, contact);
        user.vehicle = vehicle;
        user.licence = licence;

        ProgressDialog dialog = ProgressDialog.show(this, "Loading", "Please wait!");
        Response response = new Response() {
            @Override
            public void response(boolean success, String message) {
                dialog.dismiss();
                if (success){
                    Intent intent = new Intent(RegisterActivity.this, ConfirmActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("mobile", contact);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            }
        };

        Function.register_basic(user, password, null, response, this);



    }

    protected float dp_to_px(float dip){

        Resources r = getResources();
        float px = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dip,
                r.getDisplayMetrics()
        );
        return px;
    }
}