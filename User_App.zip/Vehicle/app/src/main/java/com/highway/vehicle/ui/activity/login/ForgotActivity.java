package com.highway.vehicle.ui.activity.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.highway.vehicle.R;
import com.highway.vehicle.logic.Sanitize;
import com.highway.vehicle.logic.Validation;
import com.highway.vehicle.logic.firebase.Function;

public class ForgotActivity extends AppCompatActivity {

    boolean first = true;
    String mobile;
    Function.verify_phone verify_phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.pre_app_background));


        setContentView(R.layout.activity_pre_forgot_reset_password);

        EditText phone = findViewById(R.id.apfrp_username);
        phone.setText(mobile);

        verify_phone = new Function.verify_phone(this) {
            @Override
            public void error(String error) {
                Toast.makeText(ForgotActivity.this, error, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCredential(PhoneAuthCredential credential) {
                FirebaseAuth instance = FirebaseAuth.getInstance();
                FirebaseUser user = instance.getCurrentUser();
                if (user != null){
                    signInWithPhoneAuthCredential(credential);
                    return;
                }

                Toast.makeText(ForgotActivity.this,
                        getString(R.string.unknown_error_occurred),
                        Toast.LENGTH_SHORT).show();
            }
        };

        Button reset = findViewById(R.id.apfrp_reset);
        reset.setOnClickListener(v -> {
            String mobile = phone.getText().toString();
            if (Validation.phone(mobile)){
                send_verification(Sanitize.phone(mobile));
            }else {
                Toast.makeText(ForgotActivity.this,
                        getString(R.string.invalid_mobile_number),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void send_verification(String mobile){
        this.mobile = mobile;
        verify_phone.send_verification(mobile);

        setContentView(R.layout.activity_pre_forgot_verify);

        TextView sub_title = findViewById(R.id.textView4);

        sub_title.setText(getString(R.string.please_enter_6_digit_code_sent_to, mobile));

        Button verify = findViewById(R.id.apfv_verify);
        verify.setOnClickListener(v -> {
            EditText v_1 = findViewById(R.id.apfv_1);
            EditText v_2 = findViewById(R.id.apfv_2);
            EditText v_3 = findViewById(R.id.apfv_3);
            EditText v_4 = findViewById(R.id.apfv_4);
            EditText v_5 = findViewById(R.id.apfv_5);
            EditText v_6 = findViewById(R.id.apfv_6);

            String c_1 = v_1.getText().toString();
            String c_2 = v_2.getText().toString();
            String c_3 = v_3.getText().toString();
            String c_4 = v_4.getText().toString();
            String c_5 = v_5.getText().toString();
            String c_6 = v_6.getText().toString();

            String code = c_1 + c_2 + c_3 + c_4 + c_5 + c_6;
            if (code.length() < 6 || code.matches("[0-9]")){
                Toast.makeText(ForgotActivity.this, getString(R.string.invalid_code),
                        Toast.LENGTH_SHORT).show();
                return;
            }

            verify_phone.verify(code);
        });

        TextView resend = findViewById(R.id.apfv_resend);
        resend.setOnClickListener(v -> {
            verify_phone.resend_code();
        });


    }


    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = task.getResult().getUser();
                        if (user == null){
                            Toast.makeText(ForgotActivity.this,
                                    getString(R.string.unknown_error_occurred), Toast.LENGTH_SHORT).show();
                            return;
                        }

                        setup_reset(user);
                    }
                    else {

                        if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                            // The verification code entered was invalid
                        }
                    }
                });
    }

    private void setup_reset(FirebaseUser user){
        setContentView(R.layout.activity_pre_forgot_add_new_password);

        Button save = findViewById(R.id.apfanp_save);
        save.setOnClickListener(v -> {
            EditText pass = findViewById(R.id.apfanp_password);
            EditText conf = findViewById(R.id.apfanp_password_conf);

            String p = pass.getText().toString();
            String c = conf.getText().toString();

            if (!p.equals(c)){
                Toast.makeText(ForgotActivity.this, getString(R.string.passwords_do_not_match), Toast.LENGTH_SHORT).show();
                return;
            }

            if (p.length() < 6){
                Toast.makeText(ForgotActivity.this, getString(R.string.password_is_weak), Toast.LENGTH_SHORT).show();
                return;
            }

            user.updatePassword(p).addOnCompleteListener(task -> {
                if (task.isSuccessful()){
                    startActivity(new Intent(ForgotActivity.this, LoginActivity.class));
                }else {
                    Toast.makeText(ForgotActivity.this, getString(R.string.unable_to_update_password), Toast.LENGTH_SHORT).show();
                    return;
                }
            });
        });

    }

}
